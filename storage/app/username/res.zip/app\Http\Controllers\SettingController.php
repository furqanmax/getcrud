<?php

namespace App\Http\Controllers;

use App\Setting;
use Illuminate\Http\Request;

class SettingController extends Controller
{

    

        public function index()
        {
          $settings = Setting::orderBy('updated_at','desc')->get();
          
          return view('settings.index',compact('settings')); 
        }

        public function create()
        {
          return view('settings.create');
        }        
        
        public function store(Request $request)
        {
           $this->validate($request,
                 
          ]);
          $settings  = new Setting();
          
                $settings->user = $request->user;
        if($request->file('profile')) {
            $upload = $request->file('profile');
            $fileformat = time().$upload->getClientOriginalName();
            if ($upload->move('uploads/settings/', $fileformat)) {
                $settings->profile = $fileformat;
            }
        }

                $settings->mobilno = $request->mobilno;
                $settings->fasdasdf = $request->fasdasdf;
                $settings->asdf = $request->asdf;
                $settings-> = $request->;
          if($settings ->save()){
              return redirect()->back()->with('success',' Setting Added successfully.');
          }
          else{
              return redirect()->back()->with('unsuccess','Failed try again.');
          }
        
        }

        public function show($id)
        {
          $settings = Setting::findOrFail($id);
          return view('settings.show',compact('settings'));
        };

        public function edit($id)
        {
            $settings = Setting::findOrFail($id);
            return view('settings.edit',compact('settings'));
        }        
        
        public function update(Request $request, $id)
        {
            $this->validate($request,[ 
                 
            ]);

            $settings = Setting::findOrFail($id);
                
                $settings->user = $request->user;
        if($request->file('profile')) {
            $upload = $request->file('profile');
            $fileformat = time().$upload->getClientOriginalName();
            if ($upload->move('uploads/settings/', $fileformat)) {
                $settings->profile = $fileformat;
            }
        }

                $settings->mobilno = $request->mobilno;
                $settings->fasdasdf = $request->fasdasdf;
                $settings->asdf = $request->asdf;
                $settings-> = $request->;

            if($settings ->update()){
                return redirect()->back()->with('success','  settings  Added successfully.');
            }
            else{
                return redirect()->back()->with('unsuccess','Failed try again.');
            }
            
        }        
        
        public function destroy($id)
        {
            $settings = Setting::findOrFail($id);
                        if($settings->profile !=="no-image.png"){
            unlink('uploads/settings/'.$settings->profile );
        } 
            if( Setting::where('id',$id)->delete()){
                return redirect()->back()->with('success','  settings  deleted successfully.');
            }
            else{
                return redirect()->back()->with('unsuccess','Failed try again.');
            }
        }


}