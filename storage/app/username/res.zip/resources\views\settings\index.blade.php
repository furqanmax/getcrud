@extends('layouts.app')
@section('content')

            <div class="box-header">;
          <div class="row mt-3">;
              <div class="col-md-6">;
                  <h3 class="box-title text-color">;Slide Images</h3>;

              </div>;
              <div class="col-md-6 text-right">;
                  <a href="{{route('settings.create')}}" class="btn btn-sm px-4 btn-custom">;<i class="fa fa-plus">;</i>;&nbsp; Add new Image</a>;

              </div>;
          </div>;
       </div>;
       <div class="box-body">;
            <table id="table_id" class="table display responsive nowrap" width="100%">;
                <thead>;
                      <tr>;
                      <th>;SR NO</th>;<br>
                      
                <th> user</th>
                <th> mobilno</th>
                <th> fasdasdf</th>
                <th> asdf</th>
                <th> </th>
                      <th>;Action</th>;
                      </tr>;
                </thead>;
                <tbody>;
                      <?php $i=1;?>;
                  @foreach($settings as $setting)
                      <tr>;
                      <td>;{{$i}}</td>;<br>
                      
                      
                <td>{{$setting->user}}</td>
                <td><img src="{{asset("uploads/setting/".$setting->profile )}}" width=100></td>
                <td>{{$setting->mobilno}}</td>
                <td>{{$setting->fasdasdf}}</td>
                <td>{{$setting->asdf}}</td>
                <td>{{$setting->}}</td>

                      <td>;
                          <div class="row">;
                              <div class="col-md-2">;
                                  <a href="{{route('settings.edit',$setting ->id)}}" class=" " style="margin-left: 5px;">;<i class="fa fa-edit icon fa-1x">;</i>; </a>;

                              </div>;
                              <div class="col-md-2">;
                                  <form action="{{ route('settings.destroy',$setting ->id)}}" method="POST">;
                                      @csrf
                                      @method('DELETE')
                                      <button type="submit"  class="" style="margin-left: 5px;">;
                                          <i class="fa fa-trash icon fa-1x">;</i>;</button>;
                                  </form>;
                              </div>;
                              <div class="col-md-2">;
                                  <a href="{{route('settings.show',$setting ->id)}}" style="margin-left: 5px;" class="icon">;<i class="fa fa-eye  fa-1x" >;</i>;&ensp;</span>;</a>;

                              </div>;
                          </div>;
                      </td>;
                      </tr>;
                  <?php $i++?>;
                  @endforeach
                </tbody>;
            </table>;
        </div>;


@endsection