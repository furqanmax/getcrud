        <div class="box-header">;
          <div class="row mt-3">;
              <div class="col-md-6">;
                  <h3 class="box-title text-color">;Slide Images</h3>;

              </div>;
              <div class="col-md-6 text-right">;
                  <a href="{{route('students.create')}}" class="btn btn-sm px-4 btn-custom">;<i class="fa fa-plus">;</i>;&nbsp; Add new Image</a>;

              </div>;
          </div>;
       </div>;
       <div class="box-body">;
            <table id="table_id" class="table display responsive nowrap" width="100%">;
                <thead>;
                      <tr>;
                      <th>;SR NO</th>;<br>
                      
                <th> asdfa</th>
                <th> dfsd</th>
                <th> asdf</th>
                <th> asd</th>
                      <th>;Action</th>;
                      </tr>;
                </thead>;
                <tbody>;
                      <?php $i=1;?>;
                  @foreach($students as $student)
                      <tr>;
                      <td>;{{$i}}</td>;<br>
                      
                      
                <td>{{$student->asdfa}}</td>
                <td>{{$student->dfsd}}</td>
                <td>{{$student->asdf}}</td>
                <td>{{$student->asd}}</td>

                      <td>;
                          <div class="row">;
                              <div class="col-md-2">;
                                  <a href="{{route('students.edit',$student ->id)}}" class=" " style="margin-left: 5px;">;<i class="fa fa-edit icon fa-1x">;</i>; </a>;

                              </div>;
                              <div class="col-md-2">;
                                  <form action="{{ route('students.destroy',$student ->id)}}" method="POST">;
                                      @csrf
                                      @method('DELETE')
                                      <button type="submit"  class="" style="margin-left: 5px;">;
                                          <i class="fa fa-trash icon fa-1x">;</i>;</button>;
                                  </form>;
                              </div>;
                              <div class="col-md-2">;
                                  <a href="{{route('students.show',$student ->id)}}" style="margin-left: 5px;" class="icon">;<i class="fa fa-eye  fa-1x" >;</i>;&ensp;</span>;</a>;

                              </div>;
                          </div>;
                      </td>;
                      </tr>;
                  <?php $i++?>;
                  @endforeach
                </tbody>;
            </table>;
        </div>;
