        <div class="box-header">;
          <div class="row mt-3">;
              <div class="col-md-6">;
                  <h3 class="box-title text-color">;Slide Images</h3>;

              </div>;
              <div class="col-md-6 text-right">;
                  <a href="{{route('dfas.create')}}" class="btn btn-sm px-4 btn-custom">;<i class="fa fa-plus">;</i>;&nbsp; Add new Image</a>;

              </div>;
          </div>;
       </div>;
       <div class="box-body">;
            <table id="table_id" class="table display responsive nowrap" width="100%">;
                <thead>;
                      <tr>;
                      <th>;SR NO</th>;<br>
                      
                <th> ad</th>
                <th> adf</th>
                <th> ff</th>
                <th> s</th>
                <th> ads</th>
                      <th>;Action</th>;
                      </tr>;
                </thead>;
                <tbody>;
                      <?php $i=1;?>;
                  @foreach($dfas as $dfa)
                      <tr>;
                      <td>;{{$i}}</td>;<br>
                      
                      
                <td>{{$dfa->ad}}</td>
                <td>{{$dfa->adf}}</td>
                <td>{{$dfa->ff}}</td>
                <td>{{$dfa->s}}</td>
                <td>{{$dfa->ads}}</td>

                      <td>;
                          <div class="row">;
                              <div class="col-md-2">;
                                  <a href="{{route('dfas.edit',$dfa ->id)}}" class=" " style="margin-left: 5px;">;<i class="fa fa-edit icon fa-1x">;</i>; </a>;

                              </div>;
                              <div class="col-md-2">;
                                  <form action="{{ route('dfas.destroy',$dfa ->id)}}" method="POST">;
                                      @csrf
                                      @method('DELETE')
                                      <button type="submit"  class="" style="margin-left: 5px;">;
                                          <i class="fa fa-trash icon fa-1x">;</i>;</button>;
                                  </form>;
                              </div>;
                              <div class="col-md-2">;
                                  <a href="{{route('dfas.show',$dfa ->id)}}" style="margin-left: 5px;" class="icon">;<i class="fa fa-eye  fa-1x" >;</i>;&ensp;</span>;</a>;

                              </div>;
                          </div>;
                      </td>;
                      </tr>;
                  <?php $i++?>;
                  @endforeach
                </tbody>;
            </table>;
        </div>;
