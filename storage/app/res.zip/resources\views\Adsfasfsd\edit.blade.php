        <div class="col-md-8">
            <div class="main-card mb-3 card">
            // @include('partials.alert')
                <div class="card-body"><h5 class="card-title">Add Sectors</h5>
                    <form class="" method="post" action="{{route('adsfasfsds.update',$adsfasfsd ->id)}}" enctype="multipart/form-data">
                    @csrf
                                                    
                            <div class="position-relative form-group">
                                <label for="" class="">asfa</label>
                                <input name="asfa" id="id_asfa" placeholder="asfa"  class="form-control" value="{adsfasfsd->asfa}">
                            </div>                            
                            <div class="position-relative form-group">
                                <label for="" class="">sdf</label>
                                <input name="sdf" id="id_sdf" placeholder="sdf"  class="form-control" value="{adsfasfsd->sdf}">
                            </div>                            
                            <div class="position-relative form-group">
                                <label for="" class="">asdf</label>
                                <input name="asdf" id="id_asdf" placeholder="asdf"  class="form-control" value="{adsfasfsd->asdf}">
                            </div>                            
                            <div class="position-relative form-group">
                                <label for="" class="">asdf</label>
                                <input name="asdf" id="id_asdf" placeholder="asdf"  class="form-control" value="{adsfasfsd->asdf}">
                            </div>
                        <button class="mt-1 btn btn-primary" type="submit">Submit</button>
                    </form>
                </div>
            </div>
        </div>