        <div class="box-header">;
          <div class="row mt-3">;
              <div class="col-md-6">;
                  <h3 class="box-title text-color">;Slide Images</h3>;

              </div>;
              <div class="col-md-6 text-right">;
                  <a href="{{route('teachers.create')}}" class="btn btn-sm px-4 btn-custom">;<i class="fa fa-plus">;</i>;&nbsp; Add new Image</a>;

              </div>;
          </div>;
       </div>;
       <div class="box-body">;
            <table id="table_id" class="table display responsive nowrap" width="100%">;
                <thead>;
                      <tr>;
                      <th>;SR NO</th>;<br>
                      
                <th> asdf</th>
                <th> dfsd</th>
                <th> asdfa</th>
                <th> asd</th>
                <th> ad</th>
                      <th>;Action</th>;
                      </tr>;
                </thead>;
                <tbody>;
                      <?php $i=1;?>;
                  @foreach($teachers as $teacher)
                      <tr>;
                      <td>;{{$i}}</td>;<br>
                      
                      
                <td>{{$teacher->asdf}}</td>
                <td>{{$teacher->dfsd}}</td>
                <td>{{$teacher->asdfa}}</td>
                <td>{{$teacher->asd}}</td>
                <td>{{$teacher->ad}}</td>

                      <td>;
                          <div class="row">;
                              <div class="col-md-2">;
                                  <a href="{{route('teachers.edit',$teacher ->id)}}" class=" " style="margin-left: 5px;">;<i class="fa fa-edit icon fa-1x">;</i>; </a>;

                              </div>;
                              <div class="col-md-2">;
                                  <form action="{{ route('teachers.destroy',$teacher ->id)}}" method="POST">;
                                      @csrf
                                      @method('DELETE')
                                      <button type="submit"  class="" style="margin-left: 5px;">;
                                          <i class="fa fa-trash icon fa-1x">;</i>;</button>;
                                  </form>;
                              </div>;
                              <div class="col-md-2">;
                                  <a href="{{route('teachers.show',$teacher ->id)}}" style="margin-left: 5px;" class="icon">;<i class="fa fa-eye  fa-1x" >;</i>;&ensp;</span>;</a>;

                              </div>;
                          </div>;
                      </td>;
                      </tr>;
                  <?php $i++?>;
                  @endforeach
                </tbody>;
            </table>;
        </div>;
