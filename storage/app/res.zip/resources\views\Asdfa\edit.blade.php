        <div class="col-md-8">
            <div class="main-card mb-3 card">
            // @include('partials.alert')
                <div class="card-body"><h5 class="card-title">Add Sectors</h5>
                    <form class="" method="post" action="{{route('asdfas.update',$asdfa ->id)}}" enctype="multipart/form-data">
                    @csrf
                                                    
                            <div class="position-relative form-group">
                                <label for="" class="">sadf</label>
                                <input name="sadf" id="id_sadf" placeholder="sadf"  class="form-control" value="{asdfa->sadf}">
                            </div>                            
                            <div class="position-relative form-group">
                                <label for="" class="">asdf</label>
                                <input name="asdf" id="id_asdf" placeholder="asdf"  class="form-control" value="{asdfa->asdf}">
                            </div>                            
                            <div class="position-relative form-group">
                                <label for="" class="">asdf</label>
                                <input name="asdf" id="id_asdf" placeholder="asdf"  class="form-control" value="{asdfa->asdf}">
                            </div>                            
                            <div class="position-relative form-group">
                                <label for="" class=""></label>
                                <input name="" id="id_" placeholder=""  class="form-control" value="{asdfa->}">
                            </div>
                        <button class="mt-1 btn btn-primary" type="submit">Submit</button>
                    </form>
                </div>
            </div>
        </div>