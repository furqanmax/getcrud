        <div class="box-header">;
          <div class="row mt-3">;
              <div class="col-md-6">;
                  <h3 class="box-title text-color">;Slide Images</h3>;

              </div>;
              <div class="col-md-6 text-right">;
                  <a href="{{route('das.create')}}" class="btn btn-sm px-4 btn-custom">;<i class="fa fa-plus">;</i>;&nbsp; Add new Image</a>;

              </div>;
          </div>;
       </div>;
       <div class="box-body">;
            <table id="table_id" class="table display responsive nowrap" width="100%">;
                <thead>;
                      <tr>;
                      <th>;SR NO</th>;<br>
                      
                <th> fasdf</th>
                <th> asdf</th>
                <th> adsf</th>
                      <th>;Action</th>;
                      </tr>;
                </thead>;
                <tbody>;
                      <?php $i=1;?>;
                  @foreach($das as $da)
                      <tr>;
                      <td>;{{$i}}</td>;<br>
                      
                      
                <td>{{$da->fasdf}}</td>
                <td>{{$da->asdf}}</td>
                <td>{{$da->adsf}}</td>

                      <td>;
                          <div class="row">;
                              <div class="col-md-2">;
                                  <a href="{{route('das.edit',$da ->id)}}" class=" " style="margin-left: 5px;">;<i class="fa fa-edit icon fa-1x">;</i>; </a>;

                              </div>;
                              <div class="col-md-2">;
                                  <form action="{{ route('das.destroy',$da ->id)}}" method="POST">;
                                      @csrf
                                      @method('DELETE')
                                      <button type="submit"  class="" style="margin-left: 5px;">;
                                          <i class="fa fa-trash icon fa-1x">;</i>;</button>;
                                  </form>;
                              </div>;
                              <div class="col-md-2">;
                                  <a href="{{route('das.show',$da ->id)}}" style="margin-left: 5px;" class="icon">;<i class="fa fa-eye  fa-1x" >;</i>;&ensp;</span>;</a>;

                              </div>;
                          </div>;
                      </td>;
                      </tr>;
                  <?php $i++?>;
                  @endforeach
                </tbody>;
            </table>;
        </div>;
