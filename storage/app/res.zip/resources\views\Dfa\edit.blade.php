        <div class="col-md-8">
            <div class="main-card mb-3 card">
            // @include('partials.alert')
                <div class="card-body"><h5 class="card-title">Add Sectors</h5>
                    <form class="" method="post" action="{{route('dfas.update',$dfa ->id)}}" enctype="multipart/form-data">
                    @csrf
                                                    
                            <div class="position-relative form-group">
                                <label for="" class="">ad</label>
                                <input name="ad" id="id_ad" placeholder="ad"  class="form-control" value="{dfa->ad}">
                            </div>                            
                            <div class="position-relative form-group">
                                <label for="" class="">adf</label>
                                <input name="adf" id="id_adf" placeholder="adf"  class="form-control" value="{dfa->adf}">
                            </div>                            
                            <div class="position-relative form-group">
                                <label for="" class="">ff</label>
                                <input name="ff" id="id_ff" placeholder="ff"  class="form-control" value="{dfa->ff}">
                            </div>                            
                            <div class="position-relative form-group">
                                <label for="" class="">s</label>
                                <input name="s" id="id_s" placeholder="s"  class="form-control" value="{dfa->s}">
                            </div>                            
                            <div class="position-relative form-group">
                                <label for="" class="">ads</label>
                                <input name="ads" id="id_ads" placeholder="ads"  class="form-control" value="{dfa->ads}">
                            </div>
                        <button class="mt-1 btn btn-primary" type="submit">Submit</button>
                    </form>
                </div>
            </div>
        </div>